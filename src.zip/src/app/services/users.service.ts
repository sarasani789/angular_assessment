import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {HttpClient} from '@angular/common/http';

const API_URL = 'https://randomuser.me/api/';

@Injectable({
  providedIn: 'root'
})

export class UsersService {

  constructor(private Http: HttpClient) {
  }

  getUsers(params): Observable<any> {
    return this.Http.get(`${API_URL}?results=${params}`);
  }
}
