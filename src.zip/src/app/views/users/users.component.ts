import {Component, ViewChild} from '@angular/core';
import {UsersService} from '../../services/users.service';
import {Router} from '@angular/router';
import {ModalDirective} from 'ngx-bootstrap';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})
export class UsersComponent {
  @ViewChild('detailsModal') public detailsModal: ModalDirective;
  Users = [];
  noOfUsers: Number;
  UserDetails: any;

  constructor(private UserService: UsersService, private Route: Router) {
  }

  submitForm() {
    if (!this.noOfUsers || this.noOfUsers > 20 || this.noOfUsers < 1) {
      alert('Input should be between 1 - 20');
    } else {
      this.getUsers(this.noOfUsers);
    }
  }

  getUsers(number) {
    this.UserService.getUsers(number).subscribe((users) => {
      this.Users = users.results;
    }, (error) => {
      console.log(error);
    });
  }

  details(user) {
    // this.Route.navigate([`/details/${user.email}`]);
    this.UserDetails = user;
    this.detailsModal.show();
  }
}
